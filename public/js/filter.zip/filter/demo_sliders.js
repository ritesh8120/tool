$(function(){
    /* ION Range Slider Samples */
    
    //Default
    $('#chartData tr td').click(function()
		{
		var subject = $(this).closest("tr").find('td.pie_height_width').text();
        console.log(subject);
		});
	$("#ise_default").ionRangeSlider({
        min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
         var $this = $(this),
        from = $this.data("from"),
        to = $this.data("to");

    console.log(from + " - " + to);

    }
    });
    //End Default
	
	 //Default1
   
	$("#ise_default1").ionRangeSlider({
        min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
        var low = $('#ise_default1').data().from;
		console.log(low);
    }
    });
    //End Default1
	
	//Default2
   
	$("#ise_default2").ionRangeSlider({
        min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
        var low = $('#ise_default1').data().from;
		console.log(low);
    }
    });
    //End Default2
	
	
	//Default3
   
	$("#ise_default3").ionRangeSlider({
      min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
         var $this = $(this),
        from = $this.data("from"),
        to = $this.data("to");

    console.log(from + " - " + to);

    }
		
    });
    //End Default3
	
	//Default4
   
	$("#ise_default4").ionRangeSlider({
       min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
         var $this = $(this),
        from = $this.data("from"),
        to = $this.data("to");

    console.log(from + " - " + to);

    }
    });
    //End Default5
	
	//Default5
   
	$("#ise_default5").ionRangeSlider({
         min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
         var $this = $(this),
        from = $this.data("from"),
        to = $this.data("to");

    console.log(from + " - " + to);

    }
    });
    //End Default5
	
	//Default6
   
	$("#ise_default6").ionRangeSlider({
         min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
         var $this = $(this),
        from = $this.data("from"),
        to = $this.data("to");

    console.log(from + " - " + to);

    }
    });
    //End Default6
	
	//Default7
   
	$("#ise_default7").ionRangeSlider({
        min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
         var $this = $(this),
        from = $this.data("from"),
        to = $this.data("to");

    console.log(from + " - " + to);

    }
    });
    //End Default7
	
	//Default8
   
	$("#ise_default8").ionRangeSlider({
         min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
         var $this = $(this),
        from = $this.data("from"),
        to = $this.data("to");

    console.log(from + " - " + to);

    }
    });
    //End Default8
	
	//Default9
   
	$("#ise_default9").ionRangeSlider({
         min: 0,
        max: 10,
        from: 500,
		onChange: function (data) {
         var $this = $(this),
        from = $this.data("from"),
        to = $this.data("to");

    console.log(from + " - " + to);

    }
    });
    //End Default9
	var options = [];

$( '.dropdown-menu a' ).on( 'click', function( event ) {

   var $target = $( event.currentTarget ),
       val = $target.attr( 'data-value' ),
       $inp = $target.find( 'input' ),
       idx;
      options.push( val );
      setTimeout( function() { $inp.prop( 'checked', true ) }, 0);
   $('#show_val').val($inp.attr('value'));
   $('#show_val').dropdown-menu('hide');
   $( event.target ).blur();
      
   console.log( options );
   return false;
});
		 

    $('.genpdf').click(function(e){
		 e.preventDefault();
		var date = $('#get_date').datepicker({ dateFormat: 'dd,MM,yyyy' }).val();
		var day=$('#show_val').val();
		alert(day);
		var subject = $('#chartData tr td').closest("tr").find('td.pie_height_width.highlight').text();
		var low = $('#ise_default1').data().from;
		var home_url='http://192.168.0.140/manasyogashala/'
		 //$link = $(this);
		 //alert($link);exit;
		$.ajax
		({
			url:home_url+"member/genpdf",
			data:{"date":date,"day":day,"subject":subject,"low":low},
			dataType:"json",
			type: "POST",
			success:function (response)
			{
				
				if(response.status == '1')
				{
					 
					 //alert('monali');
				     //alert("You will now be redirected.");
					 window.location.assign(home_url+"member/loadpdfcontent");
                  
				}
				else
				{
					alert("Please fill all the feilds");
				}
		
			}
			
		});
	});
  
    /* END ION Range Slider Samples */
});      